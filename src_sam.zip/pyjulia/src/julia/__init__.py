from .core import JuliaError
from .core import LegacyJulia as Julia
from .ipy.revise import disable_revise, enable_revise
from .release import __version__
from .tools import install
