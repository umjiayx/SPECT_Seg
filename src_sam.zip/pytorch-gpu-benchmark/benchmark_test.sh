#!/bin/bash
#SBATCH --job-name=benchmark
#SBATCH --account=yuni0
#SBATCH --partition=gpu
#SBATCH --gpus=1
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --time=00:30:00
#SBATCH --mem=64g
#SBATCH --mail-user=zhonglil@med.umich.edu
#SBATCH --mail-type=ALL
#SBATCH --output=./%x-%j
if [[ $SLURM_JOB_NODELIST ]] ; then
echo "Running on"
scontrol show hostnames $SLURM_JOB_NODELIST
fi
module load python3.10-anaconda
module load cuda
export PYTHONPATH=$PWD:$PYTHONPATH
nvidia-smi --query-gpu=name --format=csv,noheader,nounits > /dev/null
nvidia-smi
if [ $? -eq 0 ]; then
    echo "CUDA is available."
else
    echo "CUDA is not available."
fi
python3.10 benchmark_models.py
